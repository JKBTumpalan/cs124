animal(cat).
animal(dog).
animal(hamster).
animal(cHicKen).
animal('sea lion').
drink(coffee).
loves(kat, dog).
loves(berna, cat).
loves(berna, coffee).